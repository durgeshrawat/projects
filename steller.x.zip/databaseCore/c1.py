a="Ram is going to school"
m=a.partition('Ram')
print(m)

