from data import channel
class AuthServices:
    def __init__(self):
        self.AuthData=channel.Channel('https://authserver.data.blog','stellerx','stellerx.incorrect')
        self.AuthID='authdata@stellerx.db'
    def FullAuth(self):
        return self.AuthData.RecieveFull(self.AuthID)

    def Check(self,username,password):
        pass

    def NewUser(self,data): #data='username:pass:name:age:gender:contct
        _newData=''
        for i in data:
            _newData+=str(i)+':' #end a new userdata with '[new]'
        self.AuthData.Send(self.AuthID,_newData)
        
    def Check(self,username,password):
        pass

if __name__=='__main__':
    AuthServices().NewUser([1,2,3,4,5,6,7])
    print(AuthServices().FullAuth())
    
        
        
