from data.channel import Channel
url=input('[URL] : ')
username=input('[USERNAME] : ')
password=input('[PASSWORD] : ')
C=Channel(url,username,password)
if C.NewChannel(input(' ->  Enter Channel/Stream Name :'))==True:
    print('Chanenl/Stream Created Successfully.')