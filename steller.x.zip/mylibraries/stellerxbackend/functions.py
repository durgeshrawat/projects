from cloudhost import Core
class Authenticate:
    def __init__(self,serverurl,username,password):
        self.query=Core.Console(serverurl,username,password)

    def createfile(self,filename,data): #filename,content of file
        self.query.CreateFile(filename,data)
        return True
        
    def upload(self,filename,data):
        self.query.Update(filename,data) #append data into file
        return True
        
    def recieve(self,filename):
        allData=self.query.ShowFullData(filename)
        allData=allData.split('[new]')
        dictionary={}
        for i in allData:
            dictionary[allData.index(i)+1]=i
        return dictionary
        #retuen all recieved data in dictionary Format

    def showfiles(self):
        return self.query.FileKeys()
        
    def clear(self,filename):
        self.query.ClearFile(filename)
        #erase all data inside file
    

class core:
    def __init__(self):
        self.authserver=Authenticate('https://onlineattendence.art.blog','stellerxotpsystem','stellerx.incorrect')
        #self.authserver.createfile('emailid','xyz.mails.com')
        print(self.authserver.showfiles())
    
    def create_account(self,info):
        _info=''
        for i in info:
            _info+=i

        #making database tree
        # self.authserver.create.

core()