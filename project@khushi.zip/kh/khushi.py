from tkinter import *
from tkinter import filedialog as dg
from tkinter import messagebox as msgbox
import PyPDF2,pyttsx3
import os
import time
import pygame
from gtts import gTTS
from threading import *
class App:
    def __init__(self,root):
        pygame.init()
        self.root=root
        self.root.title('KHUSHI-PDF READER & TTS')
        self.root.maxsize(500,400)
        self.root.minsize(500,400)
        self.MainScreen()
    def makeTTS(self):
        f=Frame(self.root,bg='grey80').place(x=0,y=0,width=500,height=500)
        Label(f,text='Make TTS (Text To Speech)',bg='grey80',font='font 18').place(x=20,y=20-5)
        Label(f,text='Text',fg='white',bg='dodger blue',font='verdana 14').place(x=20,y=68-8,width=460)
        self.text=Text(f,fg='white',bg='black',font='verdana 10')
        self.text.place(x=20,y=96-8,width=460,height=200)
        Button(f,text='Play',fg='white',bg='green',command=self.play).place(x=20,y=303-8,height=35,width=460/2)
        Button(f,text='Save',fg='white',bg='green',command=self.save).place(x=250,y=303-8,height=35,width=460/2)
        Button(f,text='Back!',fg='white',bg='red',command=self.MainScreen).place(x=20,y=340-8,height=35,width=460)
        
        
    
    def choosefilename(self):
        self.location=dg.askopenfilename()
        self.chb.config(text='Choose Another File')
        try:
            book=open(self.location,'rb')
            pdf=PyPDF2.PdfFileReader(book)
            pages=pdf.numPages
            for i in range(pages):
                page=pdf.getPage(i)
                te_=page.extractText()
                print(te_)
                def play_thread():
                    s=pyttsx3.init()
                    s.say(te_)
                    s.runAndWait()
                def thread_():
                    t1=Thread(target=play_thread)
                    t1.start()
                thread_()
                
            self.backb.config(text='Pause and Back')
            self.filename.config(text=self.location)
            self.click()
        except:
            msgbox.showwarning('ALERT','Something Went Wrong!')
        
    def click(self):
        self.playstatus.config(text='Playing',fg='green')
   
    def play(self):
        global speech
        currenttime=int(time.asctime()[8:10])
        with open('.cache\\db.txt','r+') as f:
            data=f.read()
            data=int(data[8:10])
            f.write(str(time.asctime()))
        if data<currenttime:
            files=os.listdir('.cache')
            files.remove('dn.txt')
            for i in files:
                os.system(f'rm .cache\\{i}')
        global speech
        tt_=time.time()
        Tt='.cache\\'+str(tt_)+'.mp3'
        gTTS( text=self.text.get(1.0, "end-1c") , lang='en' , slow=False ).save(Tt)
        pygame.mixer.music.load(Tt)
        pygame.mixer.music.play(1)
        
        
    def save(self):
        global speech
        t=Toplevel()
        t.geometry('300x100')
        t.title('Save File (choose name)')
        self.filename=StringVar()
        e=Entry(t,textvariable=self.filename)
        e.place(x=20,y=20,width=260,height=30)
        speech=gTTS( text=self.text.get(1.0, "end-1c") , lang='en' , slow=False )
        Button(t,text='Save',bg='green',fg='white',command=self.save2).place(x=20,y=55,width=260)
        
    def save2(self):
        global speech
        if self.filename.get()=='':
            msgbox.showwarning('oops','Try to Give Name file.')
        else:
            speech.save('audio\\'+str(self.filename.get())+".mp3")
            msgbox.showinfo('Notification','File Saved Sucessfully!')
    def listen(self):
        self.play_=False
        f=Frame(self.root,bg='grey80').place(x=0,y=0,width=500,height=500)
        self.chb=Button(f,text='Choose File',bg='yellow',command=self.choosefilename)
        self.chb.place(x=20,y=20,width=460)
        self.playstatus=Label(f,text='?',fg='red',font='verdana 60',bg='grey80')
        self.playstatus.place(x=20,y=150,width=460)
        self.filename=Label(f,text='',bg='grey80',fg='red')
        self.filename.place(x=20,y=60,width=460)
        self.backb=Button(f,text='Back!',fg='white',bg='black',command=self.MainScreen)
        self.backb.place(x=20,y=350,width=460)
        
    def MainScreen(self):
        f=Frame(self.root,bg='aquamarine').place(x=0,y=0,width=500,height=500)
        Label(f,text='Listen Favourite PDF\'s\nmake TTS',bg='aquamarine',font='verdana 22').place(x=10,y=50,width=500)
        Button(f,text='Listen',command=self.listen,bg='black',fg='aquamarine',font='verdana 17').place(x=70,y=180,width=380)
        Button(f,text='Make TTS',bg='black',fg='aquamarine',font='verdana 17',command=self.makeTTS).place(x=70,y=230,width=380)
        Label(f,text='developer@khushi',bg='black',fg='white',font='verdana 9').place(x=0,y=380,height=20,width=500)

if __name__=='__main__':
    r=Tk()
    App(r)
    r.mainloop()
        
